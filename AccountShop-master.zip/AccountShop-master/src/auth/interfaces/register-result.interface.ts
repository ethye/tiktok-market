import { LoginResult } from "./login-result.interface";

export class RegisterResult extends LoginResult {}
