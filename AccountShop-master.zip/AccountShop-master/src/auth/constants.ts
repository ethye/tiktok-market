export const jwtConstants = {
  secret: "VErysEcreT@1234",
};

export const saltOrRoundsConstants = 12;
