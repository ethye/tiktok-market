export const PAGINATE_DEFAULT = {
  PAGE: 1,
  PAGE_SIZE: 5,
};

export enum SORT_TYPE {
  ASC = "ASC",
  DESC = "DESC",
}
