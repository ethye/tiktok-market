export interface AdminBankInfo {
  bankName: string;
  accountNumber: string;
  accountName: string;
  transferContent: string;
}
